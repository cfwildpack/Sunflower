function changeBackground() {
    const colors = ["#fff8dc", "#ffe680", "#ffd633", "#fff2cc"];
    document.body.style.background = colors[Math.floor(Math.random() * colors.length)];
}

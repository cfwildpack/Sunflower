# Sunflower Garden 🌻

Simple sunflower-themed website for GitHub.

## Features
- Bright sunflower theme
- Fun facts section
- Interactive background color button

## How to Use
Open index.html in your browser.

## Future Ideas
- Add gallery of sunflowers
- Animations
- Responsive design
